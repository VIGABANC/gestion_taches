import {createBrowserRouter} from 'react-router-dom'

const router =createBrowserRouter([

])
export default router